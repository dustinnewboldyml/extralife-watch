const interval = 10 * 1000; // 10 seconds
const noSounds = process.env.npm_config_nosound || false;
const useAlert = process.env.npm_config_alert || false;
const playMessage = process.env.npm_config_play_message || false;
const messageLength = 10;

module.exports = {
    interval,
    useAlert,
    playMessage,
    noSounds
};
