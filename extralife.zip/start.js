const player = require('play-sound')(opts = {})

const tts = require('./tts');
const el = require('./extralife');
const log = require('./log');
const config = require('./config');
const chat = require('./chat.js');

const tick = () => {
	el.check()
		.then(donations => {
			// Update stats if needed
			if ( donations.new.length > 0 ) {
				log('New donations! Updating files');
				el.write(`\$${donations.stats.total}`, 'total-donated');
				el.write(donations.stats.donators, 'total-donators');
				el.write(donations.stats.donations, 'total-donations');
				el.write(`\$${donations.stats.average}`, 'average-donation');
				el.write(`\$${donations.new[0].amount}`, 'latest-amount');
				el.write(donations.new[0].message || '', 'latest-message');
				el.write(donations.new[0].displayName, 'latest-name');
				el.write(`${donations.new[0].displayName} – \$${donations.new[0].amount}`, 'latest-combined');

				donations.new.map(donation => {
					if ( donation.message ) {
						el.write(`#donation (${donation.displayName}) ${donation.message}`, 'chat', false);
					}
				})

				if ( config.noSounds ) return;

				// TTS the messages
				if ( ! config.useAlert ) {
					const promises = [];
					promises.push(tts(`New donation! ${donations.new[0].amount} from ${donations.new[0].displayName}`, 'new-donation'));
	
					if ( donations.new[0].message && config.playMessage ) {
						promises.push(tts(donations.new[0].message, 'new-message'));
					}
	
					Promise.all(promises)
						.then(() => {
							player.play('./outputs/new-donation.mp3');
						});
				} else {
					// Use simple notification instead
					player.play('./assets/donation.mp3');
				}
			}
		})
		.catch(error => {
			console.error(error);
		});
}

setInterval(tick, config.interval);
tick();

// handle chats
// el.write('', 'chat'); // clear chat file
// chat.connect();
// chat.on('message', (channel, tags, message, self) => {
//     el.write(`${channel}\n(${tags['display-name']}) ${message}\n`, 'chat', false);
//     // log(`[${new Date().toLocaleTimeString()}] [${channel}] (${tags['display-name']}) ${message}`);
// });

setInterval(() => {
	const moment = require('moment');
	const startDate = moment('2020-11-07 09:00:00', 'YYYY-M-DD HH:mm:ss');
	const endDate = moment();
	const diffSeconds = endDate.diff(startDate, 'seconds');

	let seconds = diffSeconds;

	// Set days and remove them from total seconds
	let days = Math.floor(seconds / 60 / 60 / 24);
	seconds = seconds - (days * 60 * 60 * 24);
	
	let hours = Math.floor(seconds / 60 / 60);
	seconds = seconds - (hours * 60 * 60);

	let minutes = Math.floor(seconds / 60);
	seconds = seconds - (minutes * 60);

	if ( hours < 10 ) hours = `0${hours}`;
	if ( minutes < 10 ) minutes = `0${minutes}`;
	if ( seconds < 10 ) seconds = `0${seconds}`;

	el.write(`${hours}:${minutes}:${seconds}`, 'clock');
}, 1000);