const tmi = require('tmi.js');

let channels = [
    'ymedialabs',
    'rachelthescrub',
    'gridinius',
    'mythicsmt',
    'Gebrant',
    'Elzeha',
    'Kronusdark',
    'chum__fiesta',
    'Asmongold', // purely for debugging
];

const client = new tmi.Client({
    connection: {
        secure: true,
        reconnect: true
    },
    channels: channels
});

module.exports = client;